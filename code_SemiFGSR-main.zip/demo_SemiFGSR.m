%% =================================================================
% This script runs the SemiFGSR code.
% Reference: Zhong-Cheng Wu, Gemine Vivone*, Ting-Zhu Huang*, Liang-Jian Deng
%            "Pansharpening via Semi-Framelet-Guided Sparse Reconstruction"
%             Information Fusion, 2024.
% Created by Zhong-Cheng Wu (wuzhch97@163.com)
%% =================================================================
clc
clear;
close all;
addpath(genpath([pwd,'/lib']));

% Quickly run this code simply by entering your own LR-MS and PAN images.
% I_lrms: The original LR-MS image (without upsampling);
% I_pan: The original PAN image (without replication);
paras = parasetting(I_lrms, I_pan, 'none', 'R');
[I_hrms] = main_SemiFGSR(I_lrms, I_pan, paras);
%