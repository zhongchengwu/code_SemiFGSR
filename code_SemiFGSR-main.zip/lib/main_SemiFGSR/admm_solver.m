function [X_out, Cof_X, U_out, V_out, Lambda_out] = admm_solver(I_lrms, Cof_pan, E, Xlast, par, paras, U, V, Lambda)
%
eta = paras.eta;
F_it = paras.F_it;
ratio = paras.ratio;
sensor = paras.sensor;
Nways = paras.Nways;
lambda = paras.lambda;
D = par.D;
nD =par.nD;
Level = par.Level;
Lmd_1 = Lambda{1};
Lmd_2 = Lambda{2};
%
for nstep = 1:F_it
    % update X
    X = x_solver(U, V, Xlast, Lmd_1, Lmd_2, par, paras);
    % update U
    U = u_solver(I_lrms, X, Lmd_1, par, paras);
    % update V
    Cof_X = FraDecMultiLevel(Unfold(X, Nways, 1), D, Level);
    for ki=1:Level
        for ji=1:nD-1
            for jj=1:nD-1
                if ji+jj>2
                    V{ki}{ji,jj} = (2*lambda{1}*(Cof_pan{ki}{ji,jj}+E{ki}{ji,jj}) ...
                        + eta{2}*Cof_X{ki}{ji,jj}+Lmd_2{ki}{ji,jj}) / (2*lambda{1}+eta{2});
                else
                    V{ki}{ji,jj} = (eta{2}*Cof_X{ki}{ji,jj}+Lmd_2{ki}{ji,jj}) / eta{2};
                end
            end
        end
    end
    % update Lambda
    Lmd_1 = Lmd_1 + eta{1}*(MTF_lrms(X, sensor, '', ratio) - U);
    for ki=1:Level
        for ji=1:nD-1
            for jj=1:nD-1
                Lmd_2{ki}{ji,jj} = Lmd_2{ki}{ji,jj}+ eta{2}*(Cof_X{ki}{ji,jj} - V{ki}{ji,jj});
            end
        end
    end
    %
end
%
X_out = X;
U_out = U;
V_out = V;
Lambda_out{1} = Lmd_1;
Lambda_out{2} = Lmd_2;
%
end 