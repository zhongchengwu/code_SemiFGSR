function [X_out] = main_SemiFGSR(I_lrms, I_pan, paras)
%% =================================================================
% Reference: Zhong-Cheng Wu, Gemine Vivone*, Ting-Zhu Huang*, Liang-Jian Deng
%            "Pansharpening via Semi-Framelet-Guided Sparse Reconstruction"
%             Information Fusion, 2024.
% Created by Zhong-Cheng Wu (wuzhch97@163.com)
%% =================================================================
%
if isfield(paras,'tol');     tol = paras.tol;         else  error('missing tol!');     end
if isfield(paras,'maxit');   maxit = paras.maxit;     else  error('missing maxit!');   end
if isfield(paras,'lambda');  lambda = paras.lambda;   else  error('missing lambda!');  end
%
rho = paras.rho;
ratio = paras.ratio;
sensor = paras.sensor;
Nways = paras.Nways;
X = interp23tap(I_lrms, ratio); % Initialize the X
%
frame = 1;
Level = 1;
wLevel = 1/2;
[D, R] = GenerateFrameletFilter(frame);
nD = length(D);
%
par = FFT_kernel(ratio, sensor, Nways);
par.Level = Level;
par.R = R;
par.D = D;
par.nD = nD;
%
rng('default')
Ref_pan = generate_ref_im(I_lrms, I_pan, paras);
P_transition = Unfold(Ref_pan, Nways, 1);
Cof_pan = FraDecMultiLevel(P_transition, D, Level);
%
X_transition = zeros(Nways(1), Nways(2)*Nways(3));
E = FraDecMultiLevel(X_transition, D, Level);
%
U = zeros(Nways);
V = E;
Lambda = {U, V};
Thresh = sqrt(2*lambda{2} / (2*lambda{1} + rho));
%%
X_last = X;
for iter = 1:maxit
    % Update X
    [X, Cof_X, U, V, Lambda] = admm_solver(I_lrms, Cof_pan, E, X, par, paras, U, V, Lambda);
    % Update E
    for ki=1:Level
        for ji=1:nD-1
            for jj=1:nD-1
                if ji+jj>2
                    F_coeffs = (2*lambda{1}*(Cof_X{ki}{ji,jj}-Cof_pan{ki}{ji,jj}) ...
                        + rho*E{ki}{ji,jj}) / (2*lambda{1} + rho);
                    E{ki}{ji,jj} = wthresh(F_coeffs, 'h', Thresh);
                end
            end
        end
        if wLevel<=0
            Thresh=Thresh*norm(D{1});
        else
            Thresh=Thresh*wLevel;
        end
    end
    %%
    Rel_Err = norm(Unfold(X-X_last, Nways, 3), 'fro')/norm(Unfold(X_last, Nways, 3), 'fro');
    if Rel_Err < tol  
        break;
    end
    X_last = X;
end
%
X_out = X;
%
X_out(X_out>1)=1;
X_out(X_out<0)=0;
%
fprintf('Actual iterations = %d.       ' ,  iter);
end