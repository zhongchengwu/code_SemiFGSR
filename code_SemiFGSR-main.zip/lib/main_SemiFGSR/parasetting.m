function [paras] = parasetting(I_lrms, I_pan, sensor, type)
%% =================================================================
% Reference: Zhong-Cheng Wu, Gemine Vivone*, Ting-Zhu Huang*, Liang-Jian Deng
%            "Pansharpening via Semi-Framelet-Guided Sparse Reconstruction"
%             Information Fusion, 2024.
% Created by Zhong-Cheng Wu (wuzhch97@163.com)
%% =================================================================
if nargin < 2
    error('Two parameters at least: LR-MS and PAN images');
elseif nargin == 2
    sensor = 'none';
    type = 'R';
elseif nargin == 3
    type = 'R';
end
%
if max(I_lrms(:))>1 || max(I_pan(:))>1
    error('Range: [0 1]')
end
% 
[~, ~, l] = size(I_lrms);
sz = size(I_pan);
Nways = [sz, l];
paras = [];
paras.sz = sz;
paras.Nways = Nways;
paras.F_it = 1;
paras.tol = 2*1e-5;
paras.maxit = 200;
paras.ratio = 4;
paras.sensor = sensor;
% Such parameter configuration can be further fine-tuned
% on your data, if need.
%% =============
switch sensor
    case 'none'
        if strcmp(type, 'R')
            lambda{1} = 1.2e-04;
            lambda{2} = 1.0e+20;
            eta{1} = 1.8e-02;
            eta{2} = 3.9e-03;
            rho = 7e-03;
            paras.eta = eta;
            paras.rho = rho;
            paras.lambda = lambda;
        elseif strcmp(type, 'F')
             error('Following our paper, set all parameters, or fine-tune them yourself.')
        end
    case 'QB'
         if strcmp(type, 'R')
             error('Following our paper, set all parameters, or fine-tune them yourself.')
        elseif strcmp(type, 'F')
             error('Following our paper, set all parameters, or fine-tune them yourself.')
        end
     case 'WV3'
         if strcmp(type, 'R')
             error('Following our paper, set all parameters, or fine-tune them yourself.')
        elseif strcmp(type, 'F')
             error('Following our paper, set all parameters, or fine-tune them yourself.')
         end
end
%
end