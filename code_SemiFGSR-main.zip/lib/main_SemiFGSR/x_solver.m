function X_out = x_solver(U, V, Xlast, Lmd_1, Lmd_2, par, paras)
%
eta = paras.eta;
rho = paras.rho;
Nways = paras.Nways;
Rec_V = Fold(FraRecMultiLevel(V, par.R, par.Level), Nways, 1);
Rec_L = Fold(FraRecMultiLevel(Lmd_2, par.R, par.Level), Nways, 1);
X_out = zeros(Nways);
for band = 1:Nways(3)
FFT_molecular = (eta{1}*fft2(U(:,:,band))-fft2(Lmd_1(:,:,band))).*par.fft_BT(:,:,band) +...
                            eta{2}*fft2(Rec_V(:,:,band)) - fft2(Rec_L(:,:,band)) + rho*fft2(Xlast(:,:,band));
FFT_denominator = eta{1}*par.fft_B(:,:,band).*par.fft_BT(:,:,band) + rho + eta{2} ;
X_out(:,:,band) = real(ifft2(FFT_molecular ./ FFT_denominator));
end
%
end 